# Snippet Keeper

## Overview

Snippet Keeper is a full-stack web application for storing, organizing, and managing code snippets. It features a dual-mode architecture supporting both guest users (localStorage-based) and authenticated Pro users (cloud-synced via PostgreSQL). The application is built with React/TypeScript frontend and Express/Node.js backend, designed to be mobile-friendly and PWA-ready.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state, local React state for UI
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Code Highlighting**: prism-react-renderer for syntax highlighting
- **Animations**: Framer Motion for smooth transitions
- **Build Tool**: Vite with path aliases (@/ for client/src, @shared/ for shared)

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (compiled with tsx in dev, esbuild for production)
- **Authentication**: Passport.js with local strategy, session-based auth using express-session
- **Password Hashing**: Node.js crypto (scrypt) for secure password storage

### Data Storage
- **Database**: PostgreSQL via Drizzle ORM
- **Session Store**: MemoryStore (development) - should be replaced with connect-pg-simple for production
- **Guest Mode**: localStorage for unauthenticated users (max 50 snippets)
- **Schema Location**: shared/schema.ts defines all database tables and Zod validation schemas

### API Design
- **Structure**: RESTful API under /api prefix
- **Route Definitions**: Centralized in shared/routes.ts with typed request/response schemas
- **Authentication Routes**: /api/login, /api/register, /api/logout, /api/user
- **Snippet Routes**: /api/snippets (list, create), /api/snippets/:id (get, update, delete)

### Key Design Patterns
- **Shared Code**: The shared/ directory contains schema definitions and route contracts used by both frontend and backend
- **Dual Storage Mode**: The useSnippets hook abstracts storage, automatically switching between localStorage (guest) and API (authenticated)
- **Type Safety**: Drizzle-zod generates Zod schemas from database tables for runtime validation

### Build Configuration
- **Development**: `npm run dev` runs tsx with hot reload via Vite
- **Production**: `npm run build` compiles server with esbuild and client with Vite
- **Database Migrations**: `npm run db:push` uses drizzle-kit to push schema changes

## External Dependencies

### Database
- **PostgreSQL**: Primary database, connection via DATABASE_URL environment variable
- **Drizzle ORM**: Type-safe database queries with drizzle-orm/node-postgres

### Authentication & Sessions
- **Passport.js**: Authentication middleware with passport-local strategy
- **express-session**: Session management
- **memorystore**: In-memory session store (development only)

### UI Components
- **Radix UI**: Headless component primitives (dialog, dropdown, tabs, etc.)
- **shadcn/ui**: Pre-styled Radix components with Tailwind
- **Lucide React**: Icon library

### Utilities
- **date-fns**: Date formatting and manipulation
- **zod**: Runtime type validation
- **class-variance-authority**: Component variant management
- **clsx/tailwind-merge**: Conditional class name utilities