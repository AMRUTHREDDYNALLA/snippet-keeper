import { useState } from "react";
import { Navigation } from "@/components/Navigation";
import { useSnippets } from "@/hooks/use-snippets";
import { SnippetCard } from "@/components/SnippetCard";
import { SnippetForm } from "@/components/SnippetForm";
import { Snippet } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Plus, Search, Filter, Loader2, Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { AnimatePresence, motion } from "framer-motion";

export default function Home() {
  const { snippets, isLoading, createSnippet, updateSnippet, deleteSnippet, isGuest } = useSnippets();
  const [search, setSearch] = useState("");
  const [languageFilter, setLanguageFilter] = useState<string>("all");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingSnippet, setEditingSnippet] = useState<Snippet | null>(null);

  // Derived state for filtering
  const filteredSnippets = snippets.filter(snippet => {
    const matchesSearch = 
      snippet.title.toLowerCase().includes(search.toLowerCase()) || 
      snippet.code.toLowerCase().includes(search.toLowerCase()) ||
      (snippet.tags && snippet.tags.some(tag => tag.toLowerCase().includes(search.toLowerCase())));
      
    const matchesLang = languageFilter === "all" || snippet.language.toLowerCase() === languageFilter.toLowerCase();
    
    return matchesSearch && matchesLang;
  }).sort((a, b) => {
    // Favorites first, then date
    if (a.isFavorite !== b.isFavorite) return a.isFavorite ? -1 : 1;
    return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
  });

  // Unique languages for filter
  const languages = Array.from(new Set(snippets.map(s => s.language))).sort();

  const handleCreate = async (data: any) => {
    await createSnippet.mutateAsync(data);
    setIsCreateOpen(false);
  };

  const handleUpdate = async (data: any) => {
    if (!editingSnippet) return;
    await updateSnippet.mutateAsync({ id: editingSnippet.id, ...data });
    setEditingSnippet(null);
  };

  const handleDelete = async (id: number) => {
    if (confirm("Are you sure you want to delete this snippet?")) {
      await deleteSnippet.mutateAsync(id);
    }
  };

  const handleToggleFavorite = async (id: number, isFavorite: boolean) => {
    await updateSnippet.mutateAsync({ id, isFavorite });
  };

  const exportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(snippets));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href",     dataStr);
    downloadAnchorNode.setAttribute("download", "my_snippets.json");
    document.body.appendChild(downloadAnchorNode); // required for firefox
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Navigation />
      
      <main className="flex-1 container mx-auto px-4 py-8">
        
        {/* Header Actions */}
        <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight mb-2">My Snippets</h1>
            <p className="text-muted-foreground">
              {snippets.length} {snippets.length === 1 ? 'snippet' : 'snippets'} stored
              {isGuest && <span className="ml-2 text-xs bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200 px-2 py-0.5 rounded-full">Local Storage</span>}
            </p>
          </div>
          
          <div className="flex gap-2 w-full md:w-auto">
            {isGuest && snippets.length > 0 && (
              <Button variant="outline" onClick={exportData}>Export JSON</Button>
            )}
            <Button onClick={() => setIsCreateOpen(true)} className="flex-1 md:flex-none gap-2 shadow-lg shadow-primary/20">
              <Plus className="w-4 h-4" />
              New Snippet
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8 bg-card p-4 rounded-xl shadow-sm border border-border/50">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search by title, code, or tags..." 
              className="pl-9 bg-background border-border/50 focus:bg-background transition-colors"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="w-full sm:w-[200px]">
            <Select value={languageFilter} onValueChange={setLanguageFilter}>
              <SelectTrigger>
                <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
                <SelectValue placeholder="All Languages" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Languages</SelectItem>
                {languages.map(lang => (
                  <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Content Area */}
        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
          </div>
        ) : filteredSnippets.length === 0 ? (
          <div className="text-center py-20 border-2 border-dashed border-border rounded-xl bg-muted/10">
            <div className="mb-4 inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted">
              <Search className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-medium mb-2">No snippets found</h3>
            <p className="text-muted-foreground max-w-sm mx-auto mb-6">
              {search || languageFilter !== 'all' 
                ? "Try adjusting your search filters" 
                : "Create your first code snippet to get started"}
            </p>
            {(search || languageFilter !== 'all') && (
              <Button variant="outline" onClick={() => { setSearch(""); setLanguageFilter("all"); }}>
                Clear Filters
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredSnippets.map((snippet) => (
                <motion.div
                  key={snippet.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                >
                  <SnippetCard 
                    snippet={snippet}
                    onEdit={setEditingSnippet}
                    onDelete={handleDelete}
                    onToggleFavorite={handleToggleFavorite}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* Guest Warning */}
        {isGuest && (
          <div className="mt-12">
            <Alert className="bg-primary/5 border-primary/20">
              <Info className="h-4 w-4 text-primary" />
              <AlertTitle>Guest Mode Active</AlertTitle>
              <AlertDescription>
                Snippets are stored in your browser's local storage. 
                <span className="font-semibold cursor-pointer underline ml-1" onClick={() => window.location.href='/register'}>Create an account</span> to sync across devices and keep them safe forever.
              </AlertDescription>
            </Alert>
          </div>
        )}
      </main>

      {/* Create Modal */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Snippet</DialogTitle>
            <DialogDescription>
              Save a piece of code for later use.
            </DialogDescription>
          </DialogHeader>
          <SnippetForm 
            onSubmit={handleCreate} 
            onCancel={() => setIsCreateOpen(false)}
            isSubmitting={createSnippet.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Modal */}
      <Dialog open={!!editingSnippet} onOpenChange={(open) => !open && setEditingSnippet(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Snippet</DialogTitle>
          </DialogHeader>
          <SnippetForm 
            initialData={editingSnippet || undefined}
            onSubmit={handleUpdate} 
            onCancel={() => setEditingSnippet(null)}
            isSubmitting={updateSnippet.isPending}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
