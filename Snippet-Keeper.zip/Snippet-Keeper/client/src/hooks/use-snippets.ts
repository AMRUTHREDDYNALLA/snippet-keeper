import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type Snippet, type InsertSnippet } from "@shared/routes";
import { useAuth } from "./use-auth";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

const STORAGE_KEY = "guest_snippets";

// Helper to manage local storage
const localStore = {
  get: (): Snippet[] => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  },
  set: (snippets: Snippet[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(snippets));
  },
  add: (snippet: Omit<Snippet, "id" | "createdAt" | "updatedAt">): Snippet => {
    const snippets = localStore.get();
    // Simulate DB behavior
    const newSnippet: Snippet = {
      ...snippet,
      id: Date.now(), // Simple ID generation for guest
      userId: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      tags: snippet.tags || [],
      isFavorite: snippet.isFavorite || false,
    } as any; // Cast because Date is string in JSON
    
    localStore.set([newSnippet, ...snippets]);
    return newSnippet;
  },
  update: (id: number, updates: Partial<InsertSnippet>): Snippet => {
    const snippets = localStore.get();
    const index = snippets.findIndex(s => s.id === id);
    if (index === -1) throw new Error("Snippet not found");
    
    const updated = { 
      ...snippets[index], 
      ...updates, 
      updatedAt: new Date().toISOString() 
    };
    
    snippets[index] = updated as any;
    localStore.set(snippets);
    return updated as any;
  },
  delete: (id: number) => {
    const snippets = localStore.get();
    localStore.set(snippets.filter(s => s.id !== id));
  }
};

export function useSnippets() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Determine source based on auth status
  const isGuest = !user;

  // READ
  const snippetsQuery = useQuery({
    queryKey: [api.snippets.list.path, isGuest ? 'guest' : 'pro'],
    queryFn: async () => {
      if (isGuest) {
        return localStore.get();
      }
      const res = await fetch(api.snippets.list.path);
      if (!res.ok) throw new Error("Failed to fetch snippets");
      return api.snippets.list.responses[200].parse(await res.json());
    },
  });

  // CREATE
  const createMutation = useMutation({
    mutationFn: async (data: InsertSnippet) => {
      if (isGuest) {
        // Enforce limit for guest
        const count = localStore.get().length;
        if (count >= 50) throw new Error("Guest limit reached (50 snippets). Please upgrade to Pro.");
        return localStore.add(data as any);
      }
      
      const res = await fetch(api.snippets.create.path, {
        method: api.snippets.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to create snippet");
      }
      return api.snippets.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.snippets.list.path] });
      toast({ title: "Saved", description: "Snippet created successfully" });
    },
    onError: (err) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  });

  // UPDATE
  const updateMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: number } & Partial<InsertSnippet>) => {
      if (isGuest) {
        return localStore.update(id, data);
      }
      
      const url = buildUrl(api.snippets.update.path, { id });
      const res = await fetch(url, {
        method: api.snippets.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) throw new Error("Failed to update snippet");
      return api.snippets.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.snippets.list.path] });
    }
  });

  // DELETE
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      if (isGuest) {
        return localStore.delete(id);
      }
      
      const url = buildUrl(api.snippets.delete.path, { id });
      const res = await fetch(url, { method: api.snippets.delete.method });
      if (!res.ok) throw new Error("Failed to delete snippet");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.snippets.list.path] });
      toast({ title: "Deleted", description: "Snippet removed" });
    }
  });

  return {
    snippets: snippetsQuery.data || [],
    isLoading: snippetsQuery.isLoading,
    isError: snippetsQuery.isError,
    createSnippet: createMutation,
    updateSnippet: updateMutation,
    deleteSnippet: deleteMutation,
    isGuest
  };
}
