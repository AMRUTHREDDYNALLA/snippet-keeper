import { Snippet } from "@shared/schema";
import { CodeBlock } from "./CodeBlock";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Edit2, Star, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

interface SnippetCardProps {
  snippet: Snippet;
  onEdit: (snippet: Snippet) => void;
  onDelete: (id: number) => void;
  onToggleFavorite: (id: number, isFavorite: boolean) => void;
}

export function SnippetCard({ snippet, onEdit, onDelete, onToggleFavorite }: SnippetCardProps) {
  return (
    <Card className="group overflow-hidden transition-all duration-300 hover:shadow-lg hover:border-primary/20 bg-card">
      <CardHeader className="p-4 pb-2 flex flex-row items-start justify-between space-y-0">
        <div className="flex flex-col gap-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold truncate text-lg">{snippet.title}</h3>
            {snippet.isFavorite && (
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 flex-shrink-0" />
            )}
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Badge variant="secondary" className="font-mono text-[10px] uppercase tracking-wider">
              {snippet.language}
            </Badge>
            <span>•</span>
            <span>{formatDistanceToNow(new Date(snippet.createdAt || new Date()), { addSuffix: true })}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button 
            variant="ghost" 
            size="icon" 
            className={cn("h-8 w-8", snippet.isFavorite ? "text-yellow-400 hover:text-yellow-500" : "text-muted-foreground")}
            onClick={() => onToggleFavorite(snippet.id, !snippet.isFavorite)}
          >
            <Star className={cn("w-4 h-4", snippet.isFavorite && "fill-current")} />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 text-muted-foreground hover:text-primary"
            onClick={() => onEdit(snippet)}
          >
            <Edit2 className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 text-muted-foreground hover:text-destructive"
            onClick={() => onDelete(snippet.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="max-h-[300px] overflow-hidden relative">
          <CodeBlock code={snippet.code} language={snippet.language} className="rounded-none border-x-0 border-b-0" />
          <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-card to-transparent pointer-events-none" />
        </div>
      </CardContent>

      <CardFooter className="p-3 bg-muted/20 flex flex-wrap gap-2 min-h-[44px]">
        {snippet.tags && snippet.tags.length > 0 ? (
          snippet.tags.map(tag => (
            <Badge key={tag} variant="outline" className="text-xs bg-background/50 hover:bg-background border-border/50">
              #{tag}
            </Badge>
          ))
        ) : (
          <span className="text-xs text-muted-foreground italic">No tags</span>
        )}
      </CardFooter>
    </Card>
  );
}
