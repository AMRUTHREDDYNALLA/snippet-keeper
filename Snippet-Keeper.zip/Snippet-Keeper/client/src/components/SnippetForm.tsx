import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertSnippetSchema, type Snippet } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { useEffect } from "react";

// Popular languages for the dropdown
const LANGUAGES = [
  "JavaScript", "TypeScript", "Python", "Java", "C", "C#", "C++", "HTML", "CSS", "React", "SQL", "JSON", "Bash", "Go", "Rust", "PHP", "Ruby", "Swift", "Kotlin"
];

const formSchema = insertSnippetSchema.extend({
  // Override tags to be string input in form, converted to array
  tagsString: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface SnippetFormProps {
  initialData?: Snippet;
  onSubmit: (data: any) => void;
  isSubmitting: boolean;
  onCancel: () => void;
}

export function SnippetForm({ initialData, onSubmit, isSubmitting, onCancel }: SnippetFormProps) {
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      language: "javascript",
      code: "",
      tagsString: "",
      isFavorite: false,
    },
  });

  useEffect(() => {
    if (initialData) {
      form.reset({
        title: initialData.title,
        language: initialData.language,
        code: initialData.code,
        tagsString: initialData.tags ? initialData.tags.join(", ") : "",
        isFavorite: initialData.isFavorite || false,
      });
    }
  }, [initialData, form]);

  const handleSubmit = (values: FormValues) => {
    // Convert comma-separated string back to array
    const tags = values.tagsString 
      ? values.tagsString.split(",").map(t => t.trim()).filter(Boolean)
      : [];
    
    // Remove temporary field
    const { tagsString, ...rest } = values;
    
    onSubmit({ ...rest, tags });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Title</FormLabel>
              <FormControl>
                <Input placeholder="e.g. React useEffect Hook" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="language"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Language</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {LANGUAGES.map(lang => (
                      <SelectItem key={lang.toLowerCase()} value={lang.toLowerCase()}>
                        {lang}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="tagsString"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tags (comma separated)</FormLabel>
                <FormControl>
                  <Input placeholder="hooks, frontend, basics" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="code"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Code</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="// Paste your code here..." 
                  className="font-mono min-h-[200px] resize-y" 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting} className="min-w-[100px]">
            {isSubmitting ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              initialData ? "Update" : "Create"
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}
