## Packages
prism-react-renderer | For beautiful code syntax highlighting
framer-motion | For smooth page transitions and micro-interactions
date-fns | For formatting dates nicely

## Notes
Dual mode architecture: Guest (localStorage) vs Pro (API).
UI needs to be mobile-friendly and app-like.
