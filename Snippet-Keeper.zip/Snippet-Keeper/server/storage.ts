import { db } from "./db";
import { users, snippets, type User, type InsertUser, type Snippet, type InsertSnippet, type UpdateSnippetRequest } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getSnippets(userId: number): Promise<Snippet[]>;
  createSnippet(snippet: InsertSnippet): Promise<Snippet>;
  updateSnippet(id: number, snippet: UpdateSnippetRequest): Promise<Snippet>;
  deleteSnippet(id: number): Promise<void>;
  getSnippet(id: number): Promise<Snippet | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getSnippets(userId: number): Promise<Snippet[]> {
    // Only return snippets belonging to the user
    return await db.select().from(snippets).where(eq(snippets.userId, userId));
  }

  async createSnippet(snippet: InsertSnippet): Promise<Snippet> {
    const [newSnippet] = await db.insert(snippets).values(snippet).returning();
    return newSnippet;
  }

  async updateSnippet(id: number, snippet: UpdateSnippetRequest): Promise<Snippet> {
    const [updatedSnippet] = await db.update(snippets)
      .set({ ...snippet, updatedAt: new Date() })
      .where(eq(snippets.id, id))
      .returning();
    return updatedSnippet;
  }

  async deleteSnippet(id: number): Promise<void> {
    await db.delete(snippets).where(eq(snippets.id, id));
  }

  async getSnippet(id: number): Promise<Snippet | undefined> {
    const [snippet] = await db.select().from(snippets).where(eq(snippets.id, id));
    return snippet;
  }
}

export const storage = new DatabaseStorage();
