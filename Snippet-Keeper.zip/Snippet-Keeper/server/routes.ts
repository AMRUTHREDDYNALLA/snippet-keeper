import type { Express } from "express";
import type { Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { insertSnippetSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup authentication (passport, session)
  setupAuth(app);

  // === Snippet Routes ===

  // List Snippets
  app.get(api.snippets.list.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const userId = (req.user as any).id;
    const snippets = await storage.getSnippets(userId);
    res.json(snippets);
  });

  // Get Snippet
  app.get(api.snippets.get.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const id = parseInt(req.params.id);
    const snippet = await storage.getSnippet(id);
    
    if (!snippet) {
      return res.status(404).json({ message: "Snippet not found" });
    }
    
    // Ensure user owns the snippet
    if (snippet.userId !== (req.user as any).id) {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    res.json(snippet);
  });

  // Create Snippet
  app.post(api.snippets.create.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Force userId from session
      const input = insertSnippetSchema.parse({
        ...req.body,
        userId: (req.user as any).id
      });
      
      const snippet = await storage.createSnippet(input);
      res.status(201).json(snippet);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Update Snippet
  app.put(api.snippets.update.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const id = parseInt(req.params.id);
    const existing = await storage.getSnippet(id);

    if (!existing) {
      return res.status(404).json({ message: "Snippet not found" });
    }

    if (existing.userId !== (req.user as any).id) {
      return res.status(403).json({ message: "Forbidden" });
    }

    try {
      const input = insertSnippetSchema.partial().parse(req.body);
      const updated = await storage.updateSnippet(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Delete Snippet
  app.delete(api.snippets.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const id = parseInt(req.params.id);
    const existing = await storage.getSnippet(id);

    if (!existing) {
      return res.status(404).json({ message: "Snippet not found" });
    }

    if (existing.userId !== (req.user as any).id) {
      return res.status(403).json({ message: "Forbidden" });
    }

    await storage.deleteSnippet(id);
    res.status(204).send();
  });

  return httpServer;
}
